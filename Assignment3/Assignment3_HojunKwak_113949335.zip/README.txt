1. Make sure that "matrices.txt", "Assignment3_HojunKwak_113949335.c" files are in the same directory

2. Compile "Assignment3_HojunKwak_113949335.c" with either linux terminal or any text editor that supports c

3. Run the program and follow the instructions given below:
  i: All tasks will run automatically
  ii: Check whether the "Successfully toggled!" message has been printed in Task1
  iii: Check whether a 9x9 matrix has been printed for Task2
  iv: Check whether "<output.txt generated>" message has been printed in Task3
  v: Check whether 8 lines have successfully printed in Task4

4. Once the program is successfully run, there will be a new data.bin file in the directory of the program
  - output.txt should be a matrix of 50x50 with 0, 35 and 134 at the end