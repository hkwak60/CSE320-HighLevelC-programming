1. Make sure that "macros.h", "Assignment2_HojunKwak.c", "text.txt" files are in the same directory

2. Compile "Assignment2_HojunKwak.c" with either linux terminal or any text editor that supports c

3. Run the program and follow the instructions given below:
    i. Task1 will be run automatically
    ii. Task2 will ask for the total number of int array elements. Input numbers as instructed
    iii. Task3 will ask for the total number of washing machines. Input details as instructed
    iv. Task4 will ask for a number for factorial calculation.
    v. Then input an option for necessary calculation. Input two integers as instructed
    vi. Task5 wil ask for an option for necessary calculation. Input integer(s) as instructed
    vii. Task6 will automatically run when text.txt is in the same directory

4. Once the program is successfully run, there will be a new data.bin file in the directory of the program