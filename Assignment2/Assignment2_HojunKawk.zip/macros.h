#ifndef MACROS
#define MACROS

#define SQUARE(a) (a*a)
#define CUBE(a) (a*a*a)
#define DOUBLE(a) (2*a)
#define TRIPLE(a) (3*a)



#endif
